import express from 'express';
import request from 'supertest';
import { getItemDoPedidoById } from '../controllers/ItemDoPedidoController';
import { ItemDoPedido } from '../models/ItemDoPedido';
import { Cliente } from '../models/Cliente';
import { Pedido } from '../models/Pedido';
import { Produto } from '../models/Produto';

const app = express();
app.use(express.json());
app.get('/item-do-pedido/:id', getItemDoPedidoById);

describe('GET /item-do-pedido/:id', () => {
  beforeAll(async () => {
    jest.spyOn(ItemDoPedido, 'findByPk').mockImplementation(async (id: number) => {
      if (id === 1) {
        return {
          id: 1,
          quantidade: 2,
          pedido: {
            id: 1,
            Cliente: {
              id: 1,
              nome: 'Cliente Teste'
            }
          },
          Produto: {
            id: 1,
            nome: 'Produto Teste'
          }
        } as any;
      }
      return null;
    });
  });

  it('retorna o item do pedido com informações do cliente, do pedido e do produto', async () => {
    const response = await request(app).get('/item-do-pedido/1');

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('id', 1);
    expect(response.body).toHaveProperty('pedido');
    expect(response.body.pedido).toHaveProperty('Cliente');
    expect(response.body.pedido.Cliente).toHaveProperty('nome', 'Cliente Teste');
    expect(response.body).toHaveProperty('Produto');
    expect(response.body.Produto).toHaveProperty('nome', 'Produto Teste');
  });

  it('deve retornar 404 se o item do pedido não for encontrado', async () => {
    jest.spyOn(ItemDoPedido, 'findByPk').mockResolvedValue(null);

    const response = await request(app).get('/item-do-pedido/999');

    expect(response.status).toBe(404);
    expect(response.body).toHaveProperty('message', 'Item do Pedido não encontrado');
  });

  it('deve retornar 400 se o ID não for um número', async () => {
    const response = await request(app).get('/item-do-pedido/abc');

    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('message', 'ID deve ser um número');
  });

  it('deve retornar o item do pedido em menos de 200ms', async () => {
    const start = Date.now();
    const response = await request(app).get('/item-do-pedido/1');
    const duration = Date.now() - start;

    expect(response.status).toBe(200);
    expect(duration).toBeLessThan(200);
  });
});
